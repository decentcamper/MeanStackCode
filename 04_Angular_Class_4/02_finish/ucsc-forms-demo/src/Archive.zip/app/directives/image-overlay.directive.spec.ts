import { ImageOverlayDirective } from './image-overlay.directive';

describe('ImageOverlayDirective', () => {
  it('should create an instance', () => {
    const directive = new ImageOverlayDirective();
    expect(directive).toBeTruthy();
  });
});
